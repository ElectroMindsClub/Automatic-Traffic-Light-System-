const int RED_A = 25;
const int YELLOW_A = 26;
const int GREEN_A = 27;

// منافذ الجهة B
const int RED_B = 16;
const int YELLOW_B = 17;
const int GREEN_B = 18;

// منفذ الزر
const int BUTTON_PIN = 14;

// ---------------- متغيرات إدارة الوقت وحالة النظام ----------------

enum TrafficState {
  STATE_OFF,        
  STATE_A_GREEN,    
  STATE_A_YELLOW,   
  STATE_ALL_RED_1,  
  STATE_B_GREEN,    
  STATE_B_YELLOW,   
  STATE_ALL_RED_2   
};

TrafficState currentState = STATE_OFF; 

unsigned long previousMillis = 0;      
unsigned long stateInterval = 0;       // لتحديد مدة كل حالة بدقة وثبات
bool systemActive = false;             

// ---------------- متغيرات الـ Debouncing للزر ----------------
int lastButtonState = HIGH;            
unsigned long lastDebounceTime = 0;    
const unsigned long debounceDelay = 50; 

// دوال مساعدة للتحكم في المصابيح
void setLights(int rA, int yA, int gA, int rB, int yB, int gB) {
  digitalWrite(RED_A, rA);
  digitalWrite(YELLOW_A, yA);
  digitalWrite(GREEN_A, gA);
  digitalWrite(RED_B, rB);
  digitalWrite(YELLOW_B, yB);
  digitalWrite(GREEN_B, gB);
}

void turnOffAll() {
  setLights(LOW, LOW, LOW, LOW, LOW, LOW);
}

// ---------------- دالة الإعداد ----------------
void setup() {
  pinMode(RED_A, OUTPUT);
  pinMode(YELLOW_A, OUTPUT);
  pinMode(GREEN_A, OUTPUT);
  
  pinMode(RED_B, OUTPUT);
  pinMode(YELLOW_B, OUTPUT);
  pinMode(GREEN_B, OUTPUT);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  turnOffAll();
}

// ---------------- دالة التكرار الرئيسية ----------------
void loop() {
  unsigned long currentMillis = millis(); 

  int reading = digitalRead(BUTTON_PIN);

  if (reading != lastButtonState) {
    lastDebounceTime = currentMillis;
  }

  if ((currentMillis - lastDebounceTime) > debounceDelay) {
    if (reading == LOW && !systemActive) {
      systemActive = true;              
      currentState = STATE_A_GREEN;     
      previousMillis = currentMillis;   
      stateInterval = 5000;             // مدة الحالة الأولى (5 ثوانٍ)
      setLights(LOW, LOW, HIGH, HIGH, LOW, LOW); 
    }
  }
  lastButtonState = reading; 

  // ---------------- آلة الحالة (State Machine) الآمنة ضد التراكم ----------------
  if (systemActive) {
    // استخدام الطريقة الصحيحة لحساب الفترات الزمنية لتفادي أخطاء الـ Rollover والتراكم
    if (currentMillis - previousMillis >= stateInterval) {
      previousMillis = currentMillis; // إعادة ضبط التوقيت بدقة لبداية الحالة الجديدة

      switch (currentState) {
        
        case STATE_A_GREEN:
          currentState = STATE_A_YELLOW;
          stateInterval = 2000; // 2 ثانية
          setLights(LOW, HIGH, LOW, HIGH, LOW, LOW);
          break;

        case STATE_A_YELLOW:
          currentState = STATE_ALL_RED_1;
          stateInterval = 1000; // ثانية واحدة
          setLights(HIGH, LOW, LOW, HIGH, LOW, LOW);
          break;

        case STATE_ALL_RED_1:
          currentState = STATE_B_GREEN;
          stateInterval = 5000; // 5 ثوانٍ
          setLights(HIGH, LOW, LOW, LOW, LOW, HIGH);
          break;

        case STATE_B_GREEN:
          currentState = STATE_B_YELLOW;
          stateInterval = 2000; // 2 ثانية
          setLights(HIGH, LOW, LOW, LOW, HIGH, LOW);
          break;

        case STATE_B_YELLOW:
          currentState = STATE_ALL_RED_2;
          stateInterval = 1000; // ثانية واحدة
          setLights(HIGH, LOW, LOW, HIGH, LOW, LOW);
          break;

        case STATE_ALL_RED_2:
          currentState = STATE_A_GREEN;
          stateInterval = 5000; // 5 ثوانٍ
          setLights(LOW, LOW, HIGH, HIGH, LOW, LOW);
          break;

        default:
          currentState = STATE_OFF;
          systemActive = false;
          turnOffAll();
          break;
      }
    }
  }
}